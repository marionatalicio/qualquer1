<?php

    session_start();



    function login(){

        $lista_usuarios   = file_get_contents("usuarios.json");
        $lista_convertida = json_decode($lista_usuarios, true);

        $fez_login = false;

        foreach ($lista_convertida as $usuario){

            $login = $_POST['login'];
            $senha = $_POST['senha'];


            if ($login == $usuario['login'] && $senha == $usuario['senha']) {

                $fez_login = true;

                $_SESSION['nome']        = $usuario['nome'];
                $_SESSION['esta_logado'] = true;

                header("Location: index.php");

            }
        }

        if ($fez_login == false){
            header('Location: login.php');
        }
    }



    function logout(){
        //sair
        session_destroy();
        //redirecionar
        header("Location: login.php");
    }

    //ROTAS
    if ($_GET['acao'] == 'login'){
        login();
    }

    if ($_GET['acao'] == 'sair'){
        logout();
    }
